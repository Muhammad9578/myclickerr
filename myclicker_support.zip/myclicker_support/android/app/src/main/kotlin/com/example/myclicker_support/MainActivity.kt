package com.dexcode.photo_lab_support

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
